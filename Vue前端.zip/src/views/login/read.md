1. main setting mock
2. api/user.js url
3. moudles username